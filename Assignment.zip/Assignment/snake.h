/*int snakemove(int*snkheadpos);
int* snakeheadpos();*/
int** snakecreate ();