#include <stdio.h>
#include <stdlib.h>
#include "array.h"
#include "ucpRandom.h"
int** snakecreate ()
{
    /*int* snkheadpos;*/
    int i;
    int rownumber;
    int columnnumber;
    /*snkheadpos =malloc(2*sizeof(int));*/
    int** snake = malloc(5 * sizeof(int*));
    for(i = 0; i < 5; i++)
    {
        snake[i] = malloc(2 * sizeof(int));
    }
    /*return snake;*/
    rownumber = randomRange(0, 10);
    columnnumber = randomRange(0,20);
    /*snkheadpos[0] = rownumber;
    snkheadpos[1] = columnnumber;*/
    for (i = 0; i < 5; i++)
    {
        snake[i][1] = columnnumber - i;
        snake[i][0] = rownumber;
    }  
    /*snake[0][0] = rownumber;
    snake[0][1] = columnnumber;
    snake[1][0] = snake*/
    /*return snkheadpos;*/
    return snake;
}

/*char snakemove(int*snkheadpos)
{
    bool foodnoteaten = true;
    char dir;
    char head;
    while (foodnoteaten == true)
    {
        printf("please type AWSD to move left, up, down, right\n");
        scanf("%c", &dir);
        if (dir == "w")
        {
            head = "^";
            *snkheadpos[1] = *snkheadpos[1] + 1;
        }
        if (dir == "a")
        {
            head = "<";
            *snkheadpos[2] = *snkheadpos[2] - 1;
        }
        if (dir == "s")
        {
            head = "v";
            *snkheadpos[1] = *snkheadpos[1] - 1;
        }
        if (dir == "d")
        {
            head = ">";
            *snkheadpos[2] = *snkheadpos[2] + 1;
        }
    }
    return head;
}*/