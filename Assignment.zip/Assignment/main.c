#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "array.h"
#include "ucpRandom.h"
#include "terminal.h"
#include "snake.h"
#define false 0
#define true !(false)
int main(int argc, char** argv)
{
    /*bool gameon  = true;*/
    disableBuffer();
    int i;
    int rownumber;
    int columnnumber;
    int** snakebody;
    char** world = creatmap(11,21);
    /*int* initheadpos;*/
    char dir;
    char head = '>';
    char vbody = '|';
    char hbody = '-';
    char tail = '#';
    int temp[2] = {0,0};
    int follow[2] = {0,0};
    bool boundcheck = false;
    /*int bodypos1[2];
    int bodypos2[2];
    int bodypos3[2];
    int tailpos[2];*/
    rownumber = randomRange(0, 9);
    columnnumber = randomRange(0,19);
    int foodpos[2] = {rownumber, columnnumber};
    /*initheadpos = snakeheadpos();*/
    snakebody = snakecreate();
    
    world[snakebody[0][0]][snakebody[0][1]] = head;
    world[snakebody[1][0]][snakebody[1][1]] = hbody;
    world[snakebody[2][0]][snakebody[2][1]] = hbody;
    world[snakebody[3][0]][snakebody[3][1]] = hbody;
    world[snakebody[4][0]][snakebody[4][1]] = tail;
    world[rownumber][columnnumber] = '@';
    /*printf("hello");*/
    while (snakebody[4][1] < 0)
    {
        /*initheadpos = snakeheadpos();*/
        world[snakebody[0][0]][snakebody[0][1]] = head;
        world[snakebody[1][0]][snakebody[1][1]] = hbody;
        world[snakebody[2][0]][snakebody[2][1]] = hbody;
        world[snakebody[3][0]][snakebody[3][1]] = hbody;
        world[snakebody[4][0]][snakebody[4][1]] = tail;
    }/*the whole body has to be in bound otherwise reprint the whole body*/

    while (foodpos[0] == snakebody[0][0] && foodpos[1] == snakebody[0][1])
    {
        rownumber = randomRange(0, 10);
        columnnumber = randomRange(0,20);
        int foodpos[2] = {rownumber, columnnumber};
    }/*food position can not be at same position as snake head is */

    printworld(world, 11, 21);
    world[snakebody[4][0]][snakebody[4][1]] = ' ';
    /*printf("hello");*/
    do
    {
        printf("please enter a direction for the snake <a,w,s,d>\n");
        scanf("%c", &dir);
        /*world[snakebody[0][0]][snakebody[0][1]] = ' ';*/
        if (dir == 'w')
        {
            head = '^';
            temp[0] = snakebody[0][0];
            temp[1] = snakebody[0][1];
            /*snakebody[0][0] = snakebody[0][0] - 1;*/
            while (snakebody[0][0] - 1 < 0)
            {
                printf("please do not go out of bound\n");
                snakebody[0][0] = snakebody[0][0] + 1;
                boundcheck = true;
                /*temp[0] = snakebody[0][0];
                temp[1] = snakebody[0][1];*/
            }
            snakebody[0][0] = snakebody[0][0] - 1;
            for (i = 1; i < 5; i++)
            {
                if (snakebody[i][0] == snakebody[0][0] && snakebody[i][1] == snakebody[0][1])
                {
                    printf("you lost!\n");
                    enableBuffer();
                    return 0;
                }
            }
            if (boundcheck == false)
            {
                for (i = 1; i < 5; i++)
                {
                    follow[0]= snakebody[i][0];
                    follow[1]= snakebody[i][1];
                    snakebody[i][0] = temp[0];
                    snakebody[i][1] = temp[1];
                    temp[0] = follow[0];
                    temp[1] = follow[1];
                }
            }
            world[snakebody[0][0]][snakebody[0][1]] = head;
            world[snakebody[1][0]][snakebody[1][1]] = hbody;
            world[snakebody[2][0]][snakebody[2][1]] = hbody;
            world[snakebody[3][0]][snakebody[3][1]] = hbody;
            world[snakebody[4][0]][snakebody[4][1]] = tail;

            /*snakebody[0][0] = snakebody[0][0] - 1;*/
            
            /*while (snakebody[0][0] - 1 < -1)
            {
                printf("please do not go out of bound\n");
                snakebody[0][0] = snakebody[0][0] + 2;
            }*/
            printworld(world, 11, 21);
        }
        if (dir == 'a')
        {
            head = '<';
            temp[0] = snakebody[0][0];
            temp[1] = snakebody[0][1];
            while (snakebody[0][1] - 1 < 0)
            {
                printf("please do not go out of bound\n");
                snakebody[0][1] = snakebody[0][1] + 1;
                boundcheck = true;
            }
            snakebody[0][1] = snakebody[0][1] - 1;
            for (i = 1; i < 5; i++)
            {
                if (snakebody[i][0] == snakebody[0][0] && snakebody[i][1] == snakebody[0][1])
                {
                    printf("you lost!\n");
                    enableBuffer();
                    return 0;
                }
            }
            if (boundcheck == false)
            {
                for (i = 1; i < 5; i++)
                {
                /*temp[0] = snakebody[i][0];
                temp[1] = snakebody[i][1];*/
                    follow[0]= snakebody[i][0];
                    follow[1]= snakebody[i][1];
                    snakebody[i][0] = temp[0];
                    snakebody[i][1] = temp[1];
                    temp[0] = follow[0];
                    temp[1] = follow[1];
                }            
            }
            world[snakebody[0][0]][snakebody[0][1]] = head;
            world[snakebody[1][0]][snakebody[1][1]] = hbody;
            world[snakebody[2][0]][snakebody[2][1]] = hbody;
            world[snakebody[3][0]][snakebody[3][1]] = hbody;
            world[snakebody[4][0]][snakebody[4][1]] = tail;            
            /*while (snakebody[0][1] < 0)
            {
               printf("please do not go out of bound\n");
               snakebody[0][1] = snakebody[0][1] + 2;
            }*/
            printworld(world, 11, 21);
        }

        if (dir == 's')
        {
            head = 'v';
            temp[0] = snakebody[0][0];
            temp[1] = snakebody[0][1];
            while (snakebody[0][0] + 1 > 10)
            {
                printf("please do not go out of bound\n");
                snakebody[0][0] = snakebody[0][0] - 1;
                boundcheck = true;
            }
            snakebody[0][0] = snakebody[0][0] + 1;
            for (i = 1; i < 5; i++)
            {
                if (snakebody[i][0] == snakebody[0][0] && snakebody[i][1] == snakebody[0][1])
                {
                    printf("you lost!\n");
                    enableBuffer();
                    return 0;
                }
            }
            if (boundcheck == false)
            {
                for (i = 1; i < 5; i++)
                {
                /*temp[0] = snakebody[i][0];
                temp[1] = snakebody[i][1];*/
                    follow[0]= snakebody[i][0];
                    follow[1]= snakebody[i][1];
                    snakebody[i][0] = temp[0];
                    snakebody[i][1] = temp[1];
                    temp[0] = follow[0];
                    temp[1] = follow[1];
                }
            }
            world[snakebody[0][0]][snakebody[0][1]] = head;
            world[snakebody[1][0]][snakebody[1][1]] = hbody;
            world[snakebody[2][0]][snakebody[2][1]] = hbody;
            world[snakebody[3][0]][snakebody[3][1]] = hbody;
            world[snakebody[4][0]][snakebody[4][1]] = tail;
            /*while (snakebody[0][0] > 9)
            {
                printf("please do not go out of bound\n");
                snakebody[0][0] = snakebody[0][0] -2;
            }*/
            printworld(world, 11, 21);
        }
        if (dir == 'd')
        {
            head = '>';
            temp[0] = snakebody[0][0];
            temp[1] = snakebody[0][1];
            while (snakebody[0][1] > 19)
            {
                printf("please do not go out of bound\n");
                snakebody[0][1] = snakebody[0][1] - 1;
                boundcheck = true;
            }
            snakebody[0][1] = snakebody[0][1] + 1;
            for (i = 1; i < 5; i++)
            {
                if (snakebody[i][0] == snakebody[0][0] && snakebody[i][1] == snakebody[0][1])
                {
                    printf("you lost!\n");
                    enableBuffer();
                    return 0;
                }
            }
            if (boundcheck == false)
            {
                for (i = 1; i < 5; i++)
                {
                /*temp[0] = snakebody[i][0];
                temp[1] = snakebody[i][1];*/
                    follow[0]= snakebody[i][0];
                    follow[1]= snakebody[i][1];
                    snakebody[i][0] = temp[0];
                    snakebody[i][1] = temp[1];
                    temp[0] = follow[0];
                    temp[1] = follow[1];
                }
            }
            world[snakebody[0][0]][snakebody[0][1]] = head;
            world[snakebody[1][0]][snakebody[1][1]] = hbody;
            world[snakebody[2][0]][snakebody[2][1]] = hbody;
            world[snakebody[3][0]][snakebody[3][1]] = hbody;
            world[snakebody[4][0]][snakebody[4][1]] = tail;
            /*while (snakebody[0][1] > 19)
            {
                printf("please do not go out of bound\n");
                snakebody[0][1] = snakebody[0][1] - 2;
            }*/
            printworld(world, 11, 21);
        }
        /*world[snakebody[0][0]][snakebody[0][1]] = head;*/
        /*printworld(world, 10, 20);*/
        
        world[snakebody[0][0]][snakebody[0][1]] = ' ';
        world[snakebody[1][0]][snakebody[1][1]] = ' ';
        world[snakebody[2][0]][snakebody[2][1]] = ' ';
        world[snakebody[3][0]][snakebody[3][1]] = ' ';
        world[snakebody[4][0]][snakebody[4][1]] = ' ';
        boundcheck =false;
    } while (snakebody[0][0] != foodpos [0] || snakebody[0][1] != foodpos[1]);
    enableBuffer();
    printf("you won!!\n");
    /*free(initheadpos);*/
    for (i = 0; i < 5; i++)
    {
        free(snakebody[i]);
    }
    free (snakebody);
    for (i = 0; i< 11; i++)
    {
        free (world[i]);
    }
    free(world);
    return 0;
}