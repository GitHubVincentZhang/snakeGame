char** creatmap(int height, int width);
void printworld(char** world, int height, int width);