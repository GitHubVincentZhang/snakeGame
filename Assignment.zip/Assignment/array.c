#include <stdio.h>
#include <stdlib.h>
/*int** snakecreate()
{
    int i, j;
    int** snake = malloc(4 * sizeof(int*));
    for(i = 0; i < 4; i++)
    {
        snake[i] = malloc(2 * sizeof(int));
    }
    return snake;
}*/
char** creatmap(int height, int width)
{
    int i, j;
    char** world  = malloc(height * sizeof(char*));
    for(i = 0; i < height; i++)
    {
        world[i] = malloc(width * sizeof(char));
    }
    for (i = 0; i < height; i++)
    {
        for (j = 0; j<width; j++)
        {
            world[i][j] = ' ';
        }
    }
    return world;
}

void printworld(char** world, int height, int width)
{
    int i , j;
    char star = '*';
    system("clear");
    for (i = 0; i < width; i++)
    {
        printf("%c", star);
    }
    printf("\n");
    for (i = 0; i < height; i++)
    {
        printf("%c", star);
        for (j = 0; j<width; j++)
        {
            printf("%c",world[i][j]);
        }
        printf("%c", star);
        printf("\n");
    }
    for (i = 0; i < width; i++)
    {
        printf("%c", star);
    }
    
    printf("\n");
}