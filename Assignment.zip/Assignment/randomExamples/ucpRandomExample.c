#include <stdio.h>
#include "ucpRandom.h"

int main()
{
    /* initialize some variables */
    int randomNumber;
    int x = 5, y= 10;

    /* here are some simple examples of how to use the function */

    printf("This is an example of using the ucpRandom function to generate random numbers\n");

    printf("Random number from 1 to 10: %d\n", randomRange(1, 10));
    printf("Random number from 5 to 50: %d\n", randomRange(5, 50));

    randomNumber = randomRange(10, 1000);
    printf("Random number from 10 to 1000: %d\n", randomNumber);

    randomNumber = randomRange(x, y);
    printf("Random number from x to y: %d\n", randomNumber);

    return 0;
}