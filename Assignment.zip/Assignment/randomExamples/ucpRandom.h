#ifndef USP_RANDOM_H
#define USP_RANDOM_H

/* gets a random int within a range (inclusive) */
int randomRange(int min, int max);

#endif