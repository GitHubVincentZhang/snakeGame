#include <stdlib.h>
#include <stdio.h>
#include <time.h>

/* gets a random int within a range (inclusive) */
int randomRange(int min, int max)
{
    /* seed the random number generator if needed */
    static int randomSeeded = 0;
    if(!randomSeeded)
    {
        srand(time(NULL));
        randomSeeded = 1;
    }

    /* get a random number between min and max */
    return rand() % (max - min + 1) + min;
}